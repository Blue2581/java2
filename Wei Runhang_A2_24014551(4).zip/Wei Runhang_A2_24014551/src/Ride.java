package src;
import java.util.*;

//Github link : https://github.com/Blue2581/java2

public class Ride implements RideInterface
{
    private String name;
    private String type;
    private Employee operator;
    private Queue<Visitor> queue = new LinkedList<>();
    private List<Visitor> rideHistory = new LinkedList<>();
    public Ride(){}

    public Ride(String name, String type, Employee operator)
    {
        this.name = name;
        this.type = type;
        this.operator = operator;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public String getType() 
    {
        return type;
    }

    public void setType(String type) 
    {
        this.type = type;
    }

    public Employee getOperator() 
    {
        return operator;
    }

    public void setOperator(Employee operator) 
    {
        this.operator = operator;
    }

    @Override
    public void addVisitorToQueue(Visitor visitor)
    {
        queue.add(visitor);
        System.out.println("Added visitor : " + visitor.getName() + " " + visitor.getAge() + " " + visitor.getAddress() + " " + visitor.getTicketId() + " " + visitor.getGroupSize() + " to the queue");
    }

    @Override
    public void removeVisitorFromQueue()
    {
        Visitor visitor = queue.poll();
        if(visitor != null)
        {
            System.out.println("Remove visitor : " + visitor.getName() + " from the queue.");
        }
        else
        {
            System.out.println("Queue is empty");
        }
    }

    @Override
    public void printQueue()
    {
        if(queue.isEmpty())
        {
            System.out.println("Queue is empty");
        }
        else
        {
            System.out.println("Quene : ");
            for(Visitor visitor : queue)
            {
                System.out.println(visitor.getName() + " "+ visitor.getAge() +" "+ visitor.getAddress() +" "+ visitor.getTicketId() +" "+ visitor.getGroupSize());
            }
        }
    }

    //
    @Override
    public void runOneCycle() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void addVisitorToHistory(Visitor visitor)
    {
        rideHistory.add(visitor);
    }

    @Override
    public boolean checkVisitorFromHistory(Visitor visitor)
    {
        return rideHistory.contains(visitor);
    }

    @Override
    public int numberOfVisitors() {
        return rideHistory.size();
    }

    @Override
    public void printRideHistory()
    {
        if(rideHistory.isEmpty())
        {
            System.out.println("No visitors in ride history"); 
        }
        else
        {
            System.out.println("Ride history here :");
            for(Visitor visitor : rideHistory)
            {
                System.out.println(visitor.getName() + " " + visitor.getAge() + " " + visitor.getAddress() + " " + visitor.getTicketId() + " " + visitor.getGroupSize());
            }
        }
        
    }

    
    public void sortRideHistory(Comparator<Visitor> comparator)
    {
        if(rideHistory.isEmpty())
        {
            System.out.println("No visitors in ride history to sort.");
            return;
        }
        Collections.sort(rideHistory, comparator);
        System.out.println("Ride history sorted successfully.");
    }

    public Queue<Visitor> getQueue() {
        return queue;
    }

    public void setQueue(Queue<Visitor> queue) {
        this.queue = queue;
    }

    public List<Visitor> getRideHistory() {
        return rideHistory;
    }

    public void setRideHistory(List<Visitor> rideHistory) {
        this.rideHistory = rideHistory;
    }
}