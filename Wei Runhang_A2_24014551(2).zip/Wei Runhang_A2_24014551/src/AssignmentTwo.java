package src;
//Github link : https://github.com/Blue2581/java2
public class AssignmentTwo
{
    public static void main(String[] args)
    {
        AssignmentTwo assignmentTwo = new AssignmentTwo();
        assignmentTwo.partThree();
        assignmentTwo.partFourA();
        assignmentTwo.partFourB();
        assignmentTwo.partFive();
        assignmentTwo.partSix();
        assignmentTwo.partSeven();
    }

    public void partThree()
    {
        System.out.println("Part 3 : Queue operation");
        Ride ride = new Ride("Rollar coastor", "Breathtaking", new Employee("John", 30, "123 park street", "E123", "Asumement equipment operator"));
        
        //Add tourists to the queue
        ride.addVisitorToQueue(new Visitor("Alice", 25, "Main street 456", "T101", 2));
        ride.addVisitorToQueue(new Visitor("Bob", 20, "ChaoYang street", "T102", 1));
        ride.addVisitorToQueue(new Visitor("Charlie",22,"101 Oak street", "T103", 3));
        ride.addVisitorToQueue(new Visitor("Diana", 27, "No.202 SongShu street", "T103", 1));
        ride.addVisitorToQueue(new Visitor("Eve", 30, "303 HuaShu Street", "T105", 2));

        //Remove one people from this queue
        ride.removeVisitorFromQueue();
        //Print all visitor from this queue
        ride.printQueue();
    }

    public void partFourA()
    {

    }

    public void partFourB()
    {

    }

    public void partFive()
    {

    }

    public void partSix()
    {

    }

    public void partSeven()
    {

    }
}