package src;
import java.util.*;

//Github link : https://github.com/Blue2581/java2

public class Ride implements RideInterface
{
    private String name;
    private String type;
    private Employee operator;
    private Queue<Visitor> queue = new LinkedList<>();
    public Ride(){}

    public Ride(String name, String type, Employee operator)
    {
        this.name = name;
        this.type = type;
        this.operator = operator;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Employee getOperator() {
        return operator;
    }

    public void setOperator(Employee operator) {
        this.operator = operator;
    }

    @Override
    public void addVisitorToQueue(Visitor visitor)
    {
        queue.add(visitor);
        System.out.println("Added visitor : " + visitor.getName() + " to the queue");
    }

    @Override
    public void removeVisitorFromQueue()
    {
        Visitor visitor = queue.poll();
        if(visitor != null)
        {
            System.out.println("Remove visitor : " + visitor.getName() + " from the queue.");
        }
        else
        {
            System.out.println("Queue is empty");
        }
    }

    @Override
    public void printQueue()
    {
        if(queue.isEmpty())
        {
            System.out.println("Queue is empty");
        }
        else
        {
            System.out.println("Quene : ");
            for(Visitor visitor : queue)
            {
                System.out.println(visitor.getName());
            }
        }
    }

    //
    @Override
    public void runOneCycle() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void addVisitorToHistory(Visitor var1) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean checkVisitorFromHistory(Visitor var1) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int numberOfVisitors() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void printRideHistory() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}