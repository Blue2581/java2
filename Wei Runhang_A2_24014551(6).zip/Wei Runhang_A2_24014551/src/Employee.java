package src;
//Github link : https://github.com/Blue2581/java2
public class Employee extends Person
{
    private String employeeId;
    private String jobTitle;

    public Employee(){}

    public Employee(String name, int age, String address, String employeeId, String jobTitle)
    {
        super(name,age,address);
        this.employeeId = employeeId;
        this.jobTitle = jobTitle;

    }
    
    //Getters and Setters is same as Person class
    public String getEmployeeId() 
    {
        return employeeId;
    }

    public void setEmployeeId(String employeeId)
    {
        this.employeeId = employeeId;
    }

    public String getJobTitle()
    {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle)
    {
        this.jobTitle = jobTitle;
    }

}