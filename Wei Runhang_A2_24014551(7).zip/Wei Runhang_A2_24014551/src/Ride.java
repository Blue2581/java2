package src;
import java.io.*;
import java.util.*;

//Github link : https://github.com/Blue2581/java2

public class Ride implements RideInterface
{
    private String name;
    private String type;
    private Employee operator;
    private Queue<Visitor> queue = new LinkedList<>();
    private List<Visitor> rideHistory = new LinkedList<>();
    private int maxRiders = 5;
    private int numOfCycles = 0;

    public Ride(){}

    public Ride(String name, String type, Employee operator)
    {
        this.name = name;
        this.type = type;
        this.operator = operator;
    }

    @Override
    public String toString()
    {
        return name + type;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    public String getType() 
    {
        return type;
    }

    public void setType(String type) 
    {
        this.type = type;
    }

    public Employee getOperator() 
    {
        return operator;
    }

    public void setOperator(Employee operator) 
    {
        this.operator = operator;
    }

    @Override
    public void addVisitorToQueue(Visitor visitor)
    {
        queue.add(visitor);
        System.out.println("Added visitor : " + visitor.getName() + " Age : " + visitor.getAge() + " Address : " + visitor.getAddress() + " Ticket ID : " + visitor.getTicketId() + " Group size : " + visitor.getGroupSize() + " to the queue");
    }

    @Override
    public void removeVisitorFromQueue()
    {
        Visitor visitor = queue.poll();
        if(visitor != null)
        {
            System.out.println("Remove visitor : " + visitor.getName() + " from the queue.");
        }
        else
        {
            System.out.println("Queue is empty");
        }
    }

    @Override
    public void printQueue()
    {
        if(queue.isEmpty())
        {
            System.out.println("Queue is empty");
        }
        else
        {
            System.out.println("Quene : ");
            for(Visitor visitor : queue)
            {
                System.out.println(visitor.getName() + " Age : "+ visitor.getAge() +" Address : "+ visitor.getAddress() +" Ticket ID : "+ visitor.getTicketId() +" Group size : "+ visitor.getGroupSize());
            }
        }
    }

    
    @Override
    public void runOneCycle() 
    {
        if(operator == null)
        {
            System.out.println("Cannot run ride without an operator.");
        }
        if(queue.isEmpty())
        {
            System.out.println("No visitors in the queue");
        }
        int riders = 0;
        while(!queue.isEmpty() && riders < maxRiders)
        {
            Visitor visitor = queue.poll();
            addVisitorToHistory(visitor);
            riders++;
        }
    }

    @Override
    public void addVisitorToHistory(Visitor visitor)
    {
        rideHistory.add(visitor);
    }

    @Override
    public boolean checkVisitorFromHistory(Visitor visitor)
    {
        return rideHistory.contains(visitor);
    }

    @Override
    public int numberOfVisitors() 
    {
        return rideHistory.size();
    }

    @Override
    public void printRideHistory()
    {
        if(rideHistory.isEmpty())
        {
            System.out.println("No visitors in ride history"); 
        }
        else
        {
            System.out.println("Ride history here :");
            for(Visitor visitor : rideHistory)
            {
                System.out.println(visitor.getName() + " Age: " + visitor.getAge() + " Address : " + visitor.getAddress() + " Ticked ID : " + visitor.getTicketId() + " Group size :" + visitor.getGroupSize());
            }
        }
        
    }

    
    public void sortRideHistory(Comparator<Visitor> comparator)
    {
        if(rideHistory.isEmpty())
        {
            System.out.println("No visitors in ride history to sort.");
            return;
        }
        Collections.sort(rideHistory, comparator);
        System.out.println("Ride history sorted successfully.");
    }

    public void exportRideHistory(String filename)
    {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(filename)))
        {
            for(Visitor visitor : rideHistory)
            {
                writer.write(visitor.getName() + "," + visitor.getAge() + "," + visitor.getAddress());
                writer.newLine();
            }
            System.out.println("Ride history exported to " + filename);
            
        }
        catch(IOException e)
            {
                System.out.println("Error importing ride history: " + e.getMessage());
            }
    }

    public void importRideHistory(String filename)
    {
        try(BufferedReader reader = new BufferedReader(new FileReader(filename)))
        {
            String line;
            while((line = reader.readLine()) != null)
            {
                String[] parts = line.split(",");
                Visitor visitor = new Visitor(parts[0], Integer.parseInt(parts[1]), parts[2], " ", 1);
                addVisitorToHistory(visitor);
            }
            System.out.println("Ride history imported from " + filename);
        }
        catch(IOException e)
        {
            System.out.println("Error importing ride history : " + e.getMessage());
        }
    }

    public Queue<Visitor> getQueue()
    {
        return queue;
    }

    public void setQueue(Queue<Visitor> queue)
    {
        this.queue = queue;
    }

    public List<Visitor> getRideHistory()
    {
        return rideHistory;
    }

    public void setRideHistory(List<Visitor> rideHistory)
    {
        this.rideHistory = rideHistory;
    }

    public int getMaxRiders() 
    {
        return maxRiders;
    }

    public void setMaxRiders(int maxRiders)
    {
        this.maxRiders = maxRiders;
    }

    public int getNumOfCycles()
    {
        return numOfCycles;
    }

    public void setNumOfCycles(int numOfCycles) 
    {
        this.numOfCycles = numOfCycles;
    }
}