package src;

public class Ride
{
    private String name;
    private String type;
    private Employee operator;

    public Ride(){}

    public Ride(String name, String type, Employee operator)
    {
        this.name = name;
        this.type = type;
        this.operator = operator;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Employee getOperator() {
        return operator;
    }

    public void setOperator(Employee operator) {
        this.operator = operator;
    }

}