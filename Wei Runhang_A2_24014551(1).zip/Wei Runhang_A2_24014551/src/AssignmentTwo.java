package src;

public class AssignmentTwo
{
    public static void main(String[] args)
    {

    }

    public void partThree()
    {

    }

    public void partFourA()
    {

    }

    public void partFourB()
    {

    }

    public void partFive()
    {

    }

    public void partSix()
    {

    }

    public void partSeven()
    {

    }
}