package src;
//Define these methods in the interface
public interface RideInterface
{
    void addVisitorToQueue(Visitor var1);
    void removeVisitorFromQueue();
    void printQueue();
    void runOneCycle();
    void addVisitorToHistory(Visitor var1);
    boolean checkVisitorFromHistory(Visitor var1);
    int numberOfVisitors();
    void printRideHistory();
}