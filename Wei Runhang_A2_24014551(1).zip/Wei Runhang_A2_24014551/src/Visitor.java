package src;

public class Visitor extends Person
{
    private String ticketId; //Tourist ticket number
    private int groupSize; //The number of tourists in the queue

    public Visitor(){}

    public Visitor(String name, int age, String address,String ticketId, int groupSize)
    {
        super(name, age, address);
        this.ticketId = ticketId;
        this.groupSize = groupSize;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public int getGroupSize() {
        return groupSize;
    }

    public void setGroupSize(int groupSize) {
        this.groupSize = groupSize;
    }
}