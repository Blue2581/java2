package src;
//Github link : https://github.com/Blue2581/java2
public class AssignmentTwo
{
    public static void main(String[] args)
    {
        AssignmentTwo assignmentTwo = new AssignmentTwo();
        assignmentTwo.partThree();
        assignmentTwo.partFourA();
        assignmentTwo.partFourB();
        assignmentTwo.partFive();
        assignmentTwo.partSix();
        assignmentTwo.partSeven();
    }

    public void partThree()
    {
        System.out.println("Part 3 : Queue operation");
        Ride ride = new Ride("Rollar coastor", "Breathtaking", new Employee("John", 30, "123 park street", "E123", "Asumement equipment operator"));
        //Add tourists to the queue
        ride.addVisitorToQueue(new Visitor("Alice", 25, "Main street 456", "T101", 2));
        ride.addVisitorToQueue(new Visitor("Bob", 20, "ChaoYang street", "T102", 1));
        ride.addVisitorToQueue(new Visitor("Charlie",22,"101 Oak street", "T103", 3));
        ride.addVisitorToQueue(new Visitor("Diana", 27, "No.202 SongShu street", "T103", 1));
        ride.addVisitorToQueue(new Visitor("Eve", 30, "303 HuaShu Street", "T105", 2));

        //Remove one people from this queue
        ride.removeVisitorFromQueue();
        //Print all visitor from this queue
        ride.printQueue();
        
    }

    public void partFourA()
    {
        System.out.println("Part 4 A: Linked List Operations");
        Ride ride = new Ride("Ferris wheel", "Family entertainment", new Employee("Sarah", 27, "567 park street", "E456", "Asumement equipment operator"));

        //Add tourists to the historical records of amusement facilities
        ride.addVisitorToHistory(new Visitor("Alice", 25, "Main street 456", "T101", 2));
        ride.addVisitorToHistory(new Visitor("Bob", 20, "ChaoYang street", "T102", 1));
        ride.addVisitorToHistory(new Visitor("Charlie",22,"101 Oak street", "T103", 3));
        ride.addVisitorToHistory(new Visitor("Diana", 27, "No.202 SongShu street", "T103", 1));
        ride.addVisitorToHistory(new Visitor("Eve", 30, "303 HuaShu Street", "T105", 2));

        //Check if a tourist is in the queue
        Visitor visitor = new Visitor("Jack", 25, "Main street 456", "T101", 2);
        System.out.println("Are tourists " + visitor.getName() + " in the history record : " + ride.checkVisitorFromHistory(visitor));
        //Print the number of tourists in the historical records
        System.out.println("Number of visitors in history record : " + ride.numberOfVisitors());

        //Print tourists from the historical records
        ride.printRideHistory();

    }

    public void partFourB()
    {
        System.out.println("Part 4 : Sorting set ");
        Ride ride = new Ride("Water slide" , "Adventure" , new Employee("Emma", 29, "234 Entertainment avenue", "E234" , "Asumement equipment operator"));

        //Old data here : 
        ride.addVisitorToHistory(new Visitor("Alice", 25, "Main street 456", "T101", 2));
        ride.addVisitorToHistory(new Visitor("Bob", 20, "ChaoYang street", "T102", 1));
        ride.addVisitorToHistory(new Visitor("Charlie",22,"101 Oak street", "T103", 3));
        ride.addVisitorToHistory(new Visitor("Diana", 35, "No.202 SongShu street", "T103", 1));
        ride.addVisitorToHistory(new Visitor("Eve", 30, "303 HuaShu Street", "T105", 2));

        //Add tourists to the historical records of amusement facilities
        System.out.println("Unsorted history : ");
        ride.printRideHistory();

        //Sort and print sorted history records
        ride.sortRideHistory((v1, v2) -> Integer.compare(v1.getAge(), v2.getAge()));
        System.out.println("History sorted by age :");
        ride.printRideHistory();
    }

    public void partFive()
    {
        System.out.println("Part 5: Running a Cycle");
        Ride ride = new Ride("Bumper can", "Family entertainment", new Employee("Emma", 28, "234 Entertainment Avenue", "E234", "Asumement equipent operator"));

        //Add tourists to the queue through a for loop
        for (int i = 0; i <= 10; i++) 
        {
            ride.addVisitorToQueue(new Visitor("Tourists : " + i, 18 + i , "Address : " + i , "T" + i, i));
        }
            System.out.println("Queue before running cycle:");
            ride.printQueue();

            //Run one cycle
            ride.runOneCycle();

            //Print the queue and historical records after the running cycle
            System.out.println("Queue after running cycle:");
            ride.printQueue();
            System.out.println("History after running cycle:");
            ride.printRideHistory();
        
    }

    public void partSix()
    {

    }

    public void partSeven()
    {

    }
}